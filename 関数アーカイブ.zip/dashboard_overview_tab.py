# dashboard_overview_tab.py - 完全修正版

import streamlit as st
import pandas as pd
from datetime import datetime
import logging
import hashlib
import time
import gc
import psutil

# --- dashboard_charts.py からグラフ関数をインポート ---
try:
    from dashboard_charts import (
        create_monthly_trend_chart,
        create_admissions_discharges_chart,
        create_occupancy_chart
    )
except ImportError:
    st.error("dashboard_charts.py が見つからないか、必要な関数が定義されていません。")
    create_monthly_trend_chart = None
    create_admissions_discharges_chart = None
    create_occupancy_chart = None

# --- kpi_calculator.py からKPI計算関数をインポート ---
try:
    from kpi_calculator import calculate_kpis, analyze_kpi_insights, get_kpi_status
except ImportError:
    st.error("kpi_calculator.py が見つからないか、必要な関数が定義されていません。")
    calculate_kpis = None
    analyze_kpi_insights = None
    get_kpi_status = None

# ロガーの設定
logger = logging.getLogger(__name__)

def get_color_from_status_string(status_string):
    """KPIステータス文字列に基づいて色コードを返します。"""
    if status_string == "good":
        return "#2ecc71"  # 緑
    elif status_string == "warning":
        return "#f39c12"  # オレンジ
    elif status_string == "alert":
        return "#e74c3c"  # 赤
    elif status_string == "neutral":
        return "#7f8c8d"  # 濃いグレー
    else:
        return "#BDC3C7"  # 薄いグレー

def normalize_column_names(df):
    """
    データフレームのカラム名を正規化する
    
    Parameters:
    -----------
    df : pd.DataFrame
        入力データフレーム
    
    Returns:
    --------
    pd.DataFrame
        正規化されたカラム名を持つデータフレーム
    """
    # カラム名マッピング
    column_mapping = {
        # 既存のカラム名 -> 期待されるカラム名
        '在院患者数': '日在院患者数',
        '入院患者数（在院）': '日在院患者数',
        '現在患者数': '日在院患者数',
        
        '入院患者数': '日入院患者数',
        '新入院患者数': '日入院患者数',
        
        '総入院患者数': '日総入院患者数',
        '総退院患者数': '日総退院患者数',
        
        '退院患者数': '日退院患者数',
        
        '緊急入院患者数': '日緊急入院患者数',
        
        '死亡患者数': '日死亡患者数',
        '死亡退院数': '日死亡患者数',
    }
    
    # カラム名を変更
    df_normalized = df.copy()
    for old_name, new_name in column_mapping.items():
        if old_name in df_normalized.columns and new_name not in df_normalized.columns:
            df_normalized = df_normalized.rename(columns={old_name: new_name})
    
    # 必須カラムがない場合は0で埋める
    required_columns = [
        '日入院患者数', '日在院患者数', '日死亡患者数', 
        '日緊急入院患者数', '日総入院患者数', '日総退院患者数', '日退院患者数'
    ]
    
    for col in required_columns:
        if col not in df_normalized.columns:
            # 代替ロジック
            if col == '日総入院患者数' and '日入院患者数' in df_normalized.columns:
                df_normalized[col] = df_normalized['日入院患者数']
            elif col == '日総退院患者数' and '日退院患者数' in df_normalized.columns:
                df_normalized[col] = df_normalized['日退院患者数']
            elif col == '日死亡患者数':
                df_normalized[col] = 0  # デフォルト値
            else:
                df_normalized[col] = 0
    
    return df_normalized

def display_kpi_card(title, value, subtitle, status_string="neutral"):
    """個別のKPIカードをHTMLで表示します。"""
    color = get_color_from_status_string(status_string)
    
    card_html = f"""
    <div style="
        background-color: white;
        padding: 1rem;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        border-left: 5px solid {color};
        margin-bottom: 1rem;
        height: 130px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        overflow: hidden;
    ">
        <h4 style="margin: 0 0 0.3rem 0; font-size: 0.95em; color: #555; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="{title}">{title}</h4>
        <h2 style="margin: 0.1rem 0 0.3rem 0; color: #333; font-size: 1.7em; line-height: 1.2; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="{value}">{value}</h2>
        <p style="margin: 0; font-size: 0.85em; color: {color}; font-weight: bold; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="{subtitle}">{subtitle}</p>
    </div>
    """
    st.markdown(card_html, unsafe_allow_html=True)

def get_dataframe_hash(df):
    """データフレームのハッシュを計算"""
    if df is None or df.empty:
        return "empty"
    try:
        # データの要約統計でハッシュを作成
        summary = f"{df.shape}_{df.columns.tolist()}"
        if len(df) > 100:
            # 大きなデータフレームの場合はサンプルを使用
            sample_data = df.head(50).to_string() + df.tail(50).to_string()
        else:
            sample_data = df.to_string()
        
        hash_input = summary + sample_data
        return hashlib.md5(hash_input.encode()).hexdigest()[:16]
    except Exception as e:
        logger.warning(f"データハッシュ計算エラー: {e}")
        return f"hash_error_{int(time.time())}"

@st.cache_data(ttl=1800, show_spinner=False)
def _cached_calculate_kpis(df_hash, start_date, end_date, total_beds_setting):
    """KPI計算のキャッシュ版"""
    # セッション状態から元のデータフレームを取得
    df = st.session_state.get('df')
    if df is None:
        return None
    
    # データのハッシュが一致するか確認
    current_hash = get_dataframe_hash(df)
    if current_hash != df_hash:
        logger.warning("データハッシュが一致しません。キャッシュを無効化します。")
        return None
    
    return calculate_kpis(df, start_date, end_date, total_beds=total_beds_setting)

def display_kpi_cards_only(df, start_date, end_date, total_beds_setting, target_occupancy_setting):
    """KPIカードのみを表示する関数"""
    
    try:
        if df is None or df.empty:
            logger.warning(f"KPIカード表示: データが空です。df is None: {df is None}, df.empty: {df.empty if df is not None else 'N/A'}")
            st.warning("データが読み込まれていません。")
            return
        
        if calculate_kpis is None:
            logger.error("KPIカード表示: calculate_kpis関数がインポートされていません")
            st.error("KPI計算関数が利用できません。kpi_calculator.pyを確認してください。")
            return
        
        logger.info(f"KPIカード表示開始: データ行数={len(df)}, 期間={start_date}～{end_date}")

        kpi_data = calculate_kpis(df, start_date, end_date, total_beds=total_beds_setting)
        
        if kpi_data is None or kpi_data.get("error"):
            error_msg = kpi_data.get('error', '不明') if kpi_data else '不明'
            logger.error(f"KPI計算エラー: {error_msg}")
            st.warning(f"選択された期間のKPI計算に失敗しました。理由: {error_msg}")
            return
        
        logger.info(f"KPI計算成功: {len(kpi_data)}個のメトリクスを取得")
        
        # --- KPIカード表示 ---
        st.markdown("<div class='kpi-container'>", unsafe_allow_html=True)
        
        col1, col2, col3, col4, col5 = st.columns(5)
        
        with col1:
            if "alos" in kpi_data and "alos_mom_change" in kpi_data:
                alos_status = get_kpi_status(kpi_data["alos"], 14, 18, reverse=True) if get_kpi_status else "neutral"
                alos_trend_icon = "↓" if kpi_data["alos_mom_change"] < 0 else ("↑" if kpi_data["alos_mom_change"] > 0 else "→")
                alos_trend_text = f"{alos_trend_icon} {abs(kpi_data['alos_mom_change']):.1f}% 前月比"
                display_kpi_card("平均在院日数", f"{kpi_data['alos']:.1f} 日", 
                               alos_trend_text if kpi_data["alos_mom_change"] != 0 else "前月と変動なし", 
                               alos_status)

        with col2:
            if "avg_daily_census" in kpi_data and "total_patient_days" in kpi_data:
                display_kpi_card("日平均在院患者数", f"{kpi_data['avg_daily_census']:.1f} 人", 
                               f"期間延べ: {kpi_data['total_patient_days']:,.0f} 人日", 
                               "neutral")

        with col3:
            if "bed_occupancy_rate" in kpi_data and kpi_data["bed_occupancy_rate"] is not None:
                occupancy_status = get_kpi_status(kpi_data["bed_occupancy_rate"], 
                                                target_occupancy_setting + 5, 
                                                target_occupancy_setting - 5) if get_kpi_status else "neutral"
                display_kpi_card("病床利用率", f"{kpi_data['bed_occupancy_rate']:.1f}%", 
                               f"目標: {target_occupancy_setting:.0f}%", 
                               occupancy_status)
        
        with col4:
            if "turnover_rate" in kpi_data and "days_count" in kpi_data:
                turnover_status = get_kpi_status(kpi_data["turnover_rate"], 1.0, 0.7) if get_kpi_status else "neutral"
                display_kpi_card("病床回転数 (期間)", f"{kpi_data['turnover_rate']:.2f} 回転", 
                               f"{kpi_data['days_count']} 日間実績", 
                               turnover_status)

        with col5:
            if "emergency_admission_rate" in kpi_data and "total_admissions" in kpi_data:
                emergency_status = get_kpi_status(kpi_data["emergency_admission_rate"], 15, 25, reverse=True) if get_kpi_status else "neutral"
                display_kpi_card("緊急入院比率", f"{kpi_data['emergency_admission_rate']:.1f}%", 
                               f"全入院 {kpi_data['total_admissions']:.0f} 人中", 
                               emergency_status)
        
        st.markdown("</div>", unsafe_allow_html=True)
        
    except Exception as e:
        logger.exception(f"KPIカード表示で予期しないエラー: {e}")
        st.error(f"KPIカード表示中にエラーが発生しました: {str(e)}")

def display_trend_graphs_only(df, start_date, end_date, total_beds_setting, target_occupancy_setting):
    """トレンドグラフのみを表示する関数"""
    
    # メモリ使用量の監視
    try:
        process = psutil.Process()
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB
    except:
        initial_memory = 0
    
    try:
        if df is None or df.empty:
            st.warning("データが読み込まれていません。")
            return
        
        if calculate_kpis is None:
            st.error("KPI計算関数が利用できません。")
            return

        # データハッシュを計算してキャッシュを試行
        df_hash = get_dataframe_hash(df)
        start_time = time.time()
        
        # キャッシュから取得を試みる
        kpi_data = _cached_calculate_kpis(df_hash, start_date, end_date, total_beds_setting)
        
        if kpi_data is None:
            # キャッシュミスの場合は直接計算
            kpi_data = calculate_kpis(df, start_date, end_date, total_beds=total_beds_setting)
        
        calculation_time = time.time() - start_time
        
        # デバッグ情報（開発時のみ表示）
        if st.session_state.get('debug_mode', False):
            st.info(f"KPI計算時間: {calculation_time:.3f}秒")
        
        if kpi_data is None or kpi_data.get("error"):
            st.warning(f"グラフ表示用のデータ計算に失敗しました。")
            return
        
        # --- 時系列チャート ---
        col1_chart, col2_chart = st.columns(2)
        
        with col1_chart:
            if create_monthly_trend_chart:
                st.markdown("<div class='chart-container'>", unsafe_allow_html=True)
                try:
                    monthly_chart = create_monthly_trend_chart(kpi_data)
                    if monthly_chart: 
                        st.plotly_chart(monthly_chart, use_container_width=True)
                        # チャートオブジェクトを明示的に削除
                        del monthly_chart
                    else: 
                        st.info("月次トレンドチャート: データ不足のため表示できません。")
                except Exception as e:
                    logger.error(f"月次トレンドチャート作成エラー: {e}")
                    st.error("月次トレンドチャートの作成に失敗しました。")
                finally:
                    st.markdown("</div>", unsafe_allow_html=True)
            else:
                st.warning("月次トレンドチャート関数が利用できません。")
        
        with col2_chart:
            if create_admissions_discharges_chart:
                st.markdown("<div class='chart-container'>", unsafe_allow_html=True)
                try:
                    balance_chart = create_admissions_discharges_chart(kpi_data)
                    if balance_chart: 
                        st.plotly_chart(balance_chart, use_container_width=True)
                        del balance_chart
                    else: 
                        st.info("入退院バランスチャート: データ不足のため表示できません。")
                except Exception as e:
                    logger.error(f"入退院バランスチャート作成エラー: {e}")
                    st.error("入退院バランスチャートの作成に失敗しました。")
                finally:
                    st.markdown("</div>", unsafe_allow_html=True)
            else:
                st.warning("入退院バランスチャート関数が利用できません。")
                
        # --- 病床利用率チャート（全幅） ---
        if create_occupancy_chart:
            st.markdown("<div class='chart-container full-width'>", unsafe_allow_html=True)
            try:
                occupancy_chart_fig = create_occupancy_chart(kpi_data, total_beds_setting, target_occupancy_setting)
                if occupancy_chart_fig: 
                    st.plotly_chart(occupancy_chart_fig, use_container_width=True)
                    del occupancy_chart_fig
                else: 
                    st.info("病床利用率チャート: データ不足または総病床数未設定のため表示できません。")
            except Exception as e:
                logger.error(f"病床利用率チャート作成エラー: {e}")
                st.error("病床利用率チャートの作成に失敗しました。")
            finally:
                st.markdown("</div>", unsafe_allow_html=True)
        else:
            st.warning("病床利用率チャート関数が利用できません。")
        
        # --- 分析インサイト ---
        display_insights(kpi_data, total_beds_setting)
        
        # メモリクリーンアップ
        if 'kpi_data' in locals():
            del kpi_data
        gc.collect()
        
        # メモリ使用量のログ出力
        try:
            final_memory = process.memory_info().rss / 1024 / 1024
            memory_diff = final_memory - initial_memory
            if abs(memory_diff) > 10:  # 10MB以上の変化があった場合のみログ出力
                logger.info(f"メモリ使用量変化: {memory_diff:+.1f}MB (初期: {initial_memory:.1f}MB, 最終: {final_memory:.1f}MB)")
        except:
            pass
            
    except Exception as e:
        logger.exception(f"トレンドグラフ表示で予期しないエラー: {e}")
        st.error(f"グラフ表示中にエラーが発生しました: {str(e)}")

def display_insights(kpi_data, total_beds_setting):
    """分析インサイトを表示する関数"""
    try:
        if analyze_kpi_insights and kpi_data:
            insights = analyze_kpi_insights(kpi_data, total_beds_setting)
            
            st.markdown("<div class='chart-container full-width'>", unsafe_allow_html=True)
            st.markdown("<div class='chart-title'>分析インサイトと考慮事項</div>", unsafe_allow_html=True)
            insight_col1, insight_col2 = st.columns(2)
            
            with insight_col1:
                if insights.get("alos"):
                    st.markdown("<div class='info-card'><h4>平均在院日数 (ALOS) に関する考察</h4>" + 
                               "".join([f"<p>- {i}</p>" for i in insights["alos"]]) + "</div>", 
                               unsafe_allow_html=True)
                if insights.get("weekday_pattern"):
                    st.markdown("<div class='neutral-card'><h4>曜日別パターンの活用</h4>" + 
                               "".join([f"<p>- {i}</p>" for i in insights["weekday_pattern"]]) + "</div>", 
                               unsafe_allow_html=True)
            
            with insight_col2:
                if insights.get("occupancy"):
                    st.markdown("<div class='success-card'><h4>病床利用率と回転数</h4>" + 
                               "".join([f"<p>- {i}</p>" for i in insights["occupancy"]]) + "</div>", 
                               unsafe_allow_html=True)
                if insights.get("general"):
                    st.markdown("<div class='warning-card'><h4>データ解釈上の注意点</h4>" + 
                               "".join([f"<p>- {i}</p>" for i in insights["general"]]) + "</div>", 
                               unsafe_allow_html=True)
            
            st.markdown("</div>", unsafe_allow_html=True)
        else:
            st.info("インサイトを生成するためのデータまたは関数が不足しています。")
    except Exception as e:
        logger.exception(f"インサイト表示でエラー: {e}")
        st.warning("分析インサイトの表示中にエラーが発生しました。")

def display_dashboard_overview(df, start_date, end_date, total_beds_setting, target_occupancy_setting):
    """ダッシュボード概要タブの内容を表示する統一関数"""
    
    try:
        if df is None or df.empty:
            st.warning("データが読み込まれていません。「データ処理」タブを実行してください。")
            return
        
        if calculate_kpis is None:
            st.error("KPI計算関数が利用できません。kpi_calculator.pyを確認してください。")
            return

        logger.info(f"ダッシュボード概要表示開始: データ行数={len(df)}, 期間={start_date}～{end_date}")
        
        # KPIカードとグラフを表示
        display_kpi_cards_only(df, start_date, end_date, total_beds_setting, target_occupancy_setting)
        st.markdown("---")
        display_trend_graphs_only(df, start_date, end_date, total_beds_setting, target_occupancy_setting)
        
        logger.info("ダッシュボード概要表示完了")
        
    except Exception as e:
        logger.exception(f"ダッシュボード概要表示で予期しないエラー: {e}")
        st.error(f"ダッシュボード概要の表示中にエラーが発生しました: {str(e)}")

# 後方互換性のための別名（廃止予定）
def display_overview_dashboard_modified(df, start_date, end_date, total_beds_setting, target_occupancy_setting):
    """後方互換性のための関数（廃止予定）"""
    st.warning("⚠️ display_overview_dashboard_modified は廃止予定です。display_dashboard_overview を使用してください。")
    display_dashboard_overview(df, start_date, end_date, total_beds_setting, target_occupancy_setting)

# このファイルは app.py から呼び出されることを前提としています