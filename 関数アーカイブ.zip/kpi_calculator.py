import pandas as pd
import numpy as np
import streamlit as st
import time
import gc

# kpi_calculator.py の calculate_kpis 関数を型安全性を向上させて修正

@st.cache_data(ttl=3600, show_spinner=False)
def calculate_kpis(df, start_date, end_date, total_beds=None):
    """
    指定された期間のKPIを計算する統合関数（型安全性改善版）
    
    Parameters:
    -----------
    df : pd.DataFrame
        分析対象のデータフレーム
    start_date : str or pd.Timestamp
        分析開始日
    end_date : str or pd.Timestamp
        分析終了日
    total_beds : int or None
        総病床数（病床利用率計算用）
        
    Returns:
    --------
    dict
        計算されたKPI値と集計データを含む辞書
    """
    start_time = time.time()
    
    try:
        # 日付の変換
        start_date = pd.to_datetime(start_date)
        end_date = pd.to_datetime(end_date)
        
        # 指定期間のデータをフィルタリング
        df_filtered = df[(df['日付'] >= start_date) & (df['日付'] <= end_date)].copy()
        
        if df_filtered.empty:
            return {
                "error": "指定された期間にデータがありません。",
                "processing_time": time.time() - start_time
            }
        
        # 列名の確認と自動マッピング
        column_mapping = {
            '在院患者数': ['入院患者数（在院）', '在院患者数', '現在患者数'],
            '入院患者数': ['入院患者数', '新規入院患者数'],
            '緊急入院患者数': ['緊急入院患者数', '救急入院患者数'],
            '総入院患者数': ['総入院患者数', '入院患者数合計'],
            '退院患者数': ['退院患者数', '退院者数'],
            '死亡患者数': ['死亡患者数', '死亡者数'],
            '総退院患者数': ['総退院患者数', '退院患者数合計']
        }
        
        # 実際に使用する列名を決定
        actual_columns = {}
        for standard_name, possible_names in column_mapping.items():
            found_column = None
            for possible_name in possible_names:
                if possible_name in df_filtered.columns:
                    found_column = possible_name
                    break
            
            if found_column:
                actual_columns[standard_name] = found_column
            else:
                # 必要な列が見つからない場合はデフォルト値で補完
                if standard_name == '総入院患者数' and '入院患者数' in actual_columns and '緊急入院患者数' in actual_columns:
                    df_filtered['総入院患者数'] = (
                        pd.to_numeric(df_filtered[actual_columns['入院患者数']], errors='coerce').fillna(0) +
                        pd.to_numeric(df_filtered[actual_columns['緊急入院患者数']], errors='coerce').fillna(0)
                    )
                    actual_columns[standard_name] = '総入院患者数'
                elif standard_name == '総退院患者数' and '退院患者数' in actual_columns and '死亡患者数' in actual_columns:
                    df_filtered['総退院患者数'] = (
                        pd.to_numeric(df_filtered[actual_columns['退院患者数']], errors='coerce').fillna(0) +
                        pd.to_numeric(df_filtered[actual_columns['死亡患者数']], errors='coerce').fillna(0)
                    )
                    actual_columns[standard_name] = '総退院患者数'
        
        # 必須列のチェック
        required_columns = ['在院患者数', '総入院患者数', '総退院患者数']
        missing_columns = [col for col in required_columns if col not in actual_columns]
        
        if missing_columns:
            return {
                "error": f"必要な列が見つかりません: {missing_columns}",
                "available_columns": list(df_filtered.columns),
                "processing_time": time.time() - start_time
            }
        
        # 数値列の安全な変換
        for col_name, actual_col in actual_columns.items():
            if actual_col in df_filtered.columns:
                df_filtered[actual_col] = pd.to_numeric(df_filtered[actual_col], errors='coerce').fillna(0)
        
        # 日数の計算
        days_count = (end_date - start_date).days + 1
        
        # 日次の集計（型安全）
        daily_agg_dict = {}
        for col_name, actual_col in actual_columns.items():
            daily_agg_dict[f'日{col_name}'] = (actual_col, 'sum')
        
        daily_stats = df_filtered.groupby('日付').agg(daily_agg_dict).reset_index()
        daily_stats.columns = ['日付'] + [f'日{col_name}' for col_name in actual_columns.keys()]
        
        # 期間合計の計算（安全な計算）
        def safe_sum(series):
            return pd.to_numeric(series, errors='coerce').fillna(0).sum()
        
        def safe_mean(series):
            numeric_series = pd.to_numeric(series, errors='coerce').fillna(0)
            return numeric_series.mean() if len(numeric_series) > 0 else 0
        
        total_patient_days = safe_sum(daily_stats['日在院患者数'])
        total_admissions = safe_sum(daily_stats['日総入院患者数'])
        total_discharges = safe_sum(daily_stats['日総退院患者数'])
        total_emergency_admissions = safe_sum(daily_stats.get('日緊急入院患者数', [0]))
        total_deaths = safe_sum(daily_stats.get('日死亡患者数', [0]))
        
        # 平均値の計算（安全な除算）
        def safe_divide(numerator, denominator):
            if denominator == 0 or pd.isna(denominator) or pd.isna(numerator):
                return 0
            return numerator / denominator
        
        avg_daily_census = safe_divide(total_patient_days, days_count)
        avg_daily_admissions = safe_divide(total_admissions, days_count)
        avg_daily_discharges = safe_divide(total_discharges, days_count)
        
        # 平均在院日数 (ALOS)
        denominator_alos = (total_admissions + total_discharges) / 2
        alos = safe_divide(total_patient_days, denominator_alos)
        
        # 病床回転率
        turnover_rate = safe_divide(total_discharges, avg_daily_census)
        
        # 病床利用率
        bed_occupancy_rate = None
        if total_beds is not None and total_beds > 0:
            bed_occupancy_rate = safe_divide(avg_daily_census, total_beds) * 100
        
        # 緊急入院率と死亡率（安全な計算）
        emergency_admission_rate = safe_divide(total_emergency_admissions, total_admissions) * 100
        mortality_rate = safe_divide(total_deaths, total_discharges) * 100
        
        # 病棟数と診療科数
        ward_count = df_filtered['病棟コード'].nunique() if '病棟コード' in df_filtered.columns else 0
        dept_count = df_filtered['診療科名'].nunique() if '診療科名' in df_filtered.columns else 0
        
        # 月次集計（安全な処理）
        try:
            df_filtered['年月'] = df_filtered['日付'].dt.to_period('M')
            
            monthly_agg_dict = {
                actual_columns['在院患者数']: 'sum',
                actual_columns['総入院患者数']: 'sum',
                actual_columns['総退院患者数']: 'sum',
                '日付': 'nunique'
            }
            
            monthly_stats = df_filtered.groupby('年月').agg(monthly_agg_dict).reset_index()
            monthly_stats.columns = ['年月', '延べ在院患者数', '総入院患者数', '総退院患者数', '日付数']
            monthly_stats['月'] = monthly_stats['年月'].astype(str)
            
            # 月別の平均在院日数（安全な計算）
            monthly_stats['平均在院日数'] = monthly_stats.apply(
                lambda row: safe_divide(row['延べ在院患者数'], (row['総入院患者数'] + row['総退院患者数']) / 2),
                axis=1
            )
            
            # 月別の日平均在院患者数
            monthly_stats['日平均在院患者数'] = monthly_stats.apply(
                lambda row: safe_divide(row['延べ在院患者数'], row['日付数']),
                axis=1
            )
            
        except Exception as e:
            # 月次集計でエラーが出た場合は空のDataFrameを作成
            monthly_stats = pd.DataFrame(columns=['年月', '延べ在院患者数', '総入院患者数', '総退院患者数', '日付数', '月', '平均在院日数', '日平均在院患者数'])
        
        # 前月比変化率の計算（安全な処理）
        n_months = len(monthly_stats)
        current_alos = monthly_stats['平均在院日数'].iloc[-1] if n_months > 0 else 0
        alos_mom_change = 0
        
        if n_months > 1:
            prev_alos = monthly_stats['平均在院日数'].iloc[-2]
            alos_mom_change = safe_divide(current_alos - prev_alos, abs(prev_alos)) * 100
        
        # 曜日別集計（安全な処理）
        weekday_avg_census = 0
        holiday_avg_census = 0
        
        try:
            if '平日判定' in df_filtered.columns:
                weekday_data = df_filtered[df_filtered['平日判定'] == '平日']
                holiday_data = df_filtered[df_filtered['平日判定'] == '休日']
                
                if not weekday_data.empty:
                    weekday_daily = weekday_data.groupby('日付')[actual_columns['在院患者数']].sum()
                    weekday_avg_census = safe_mean(weekday_daily)
                
                if not holiday_data.empty:
                    holiday_daily = holiday_data.groupby('日付')[actual_columns['在院患者数']].sum()
                    holiday_avg_census = safe_mean(holiday_daily)
        except Exception as e:
            # 曜日別集計でエラーが出ても続行
            pass
        
        # 週次集計（安全な処理）
        weekly_stats = pd.DataFrame()
        try:
            df_filtered['週'] = df_filtered['日付'].dt.to_period('W').astype(str)
            weekly_stats = df_filtered.groupby('週').agg({
                actual_columns['総入院患者数']: 'sum',
                actual_columns['総退院患者数']: 'sum'
            }).reset_index()
            weekly_stats.columns = ['週', '週入院患者数', '週退院患者数']
            weekly_stats['入退院差'] = weekly_stats['週入院患者数'] - weekly_stats['週退院患者数']
        except Exception as e:
            # 週次集計でエラーが出た場合は空のDataFrameを作成
            weekly_stats = pd.DataFrame(columns=['週', '週入院患者数', '週退院患者数', '入退院差'])
        
        # 結果の組み立て
        end_time = time.time()
        processing_time = end_time - start_time
        
        return {
            # 基本KPI
            "avg_daily_census": float(avg_daily_census),
            "avg_daily_admissions": float(avg_daily_admissions),
            "avg_daily_discharges": float(avg_daily_discharges),
            "alos": float(alos),
            "turnover_rate": float(turnover_rate),
            "bed_occupancy_rate": float(bed_occupancy_rate) if bed_occupancy_rate is not None else None,
            "emergency_admission_rate": float(emergency_admission_rate),
            "mortality_rate": float(mortality_rate),
            
            # 数量情報
            "ward_count": int(ward_count),
            "dept_count": int(dept_count),
            "days_count": int(days_count),
            "total_patient_days": float(total_patient_days),
            "total_admissions": float(total_admissions),
            "total_discharges": float(total_discharges),
            
            # 時系列データ
            "daily_stats": daily_stats,
            "weekly_stats": weekly_stats,
            "monthly_stats": monthly_stats,
            
            # 曜日別データ
            "weekday_avg_census": float(weekday_avg_census),
            "holiday_avg_census": float(holiday_avg_census),
            
            # 変化率
            "alos_mom_change": float(alos_mom_change),
            
            # その他
            "latest_date": df_filtered['日付'].max(),
            "start_date": start_date,
            "end_date": end_date,
            "processing_time": processing_time,
            "column_mapping_used": actual_columns
        }
        
    except Exception as e:
        end_time = time.time()
        processing_time = end_time - start_time
        
        return {
            "error": f"KPI計算中にエラーが発生しました: {str(e)}",
            "processing_time": processing_time
        }

def get_kpi_status(value, good_threshold, warning_threshold, reverse=False):
    """
    KPIの状態（良好・注意・警告）を判定する
    
    Parameters:
    -----------
    value : float
        KPI値
    good_threshold : float
        良好とみなす閾値
    warning_threshold : float
        警告とみなす閾値
    reverse : bool, default False
        Trueの場合、小さい値が良いとみなす（平均在院日数など）
        
    Returns:
    --------
    str
        "good", "warning", "alert"のいずれか
    """
    if reverse:
        if value < good_threshold:
            return "good"
        elif value < warning_threshold:
            return "warning"
        else:
            return "alert"
    else:
        if value > good_threshold:
            return "good"
        elif value > warning_threshold:
            return "warning"
        else:
            return "alert"

def analyze_kpi_insights(kpi_data, total_beds):
    """
    KPIデータからインサイトを導き出す
    
    Parameters:
    -----------
    kpi_data : dict
        calculate_kpisで計算されたKPIデータ
    total_beds : int
        総病床数
        
    Returns:
    --------
    dict
        インサイトを含む辞書
    """
    insights = {
        "alos": [],
        "occupancy": [],
        "weekday_pattern": [],
        "general": []
    }
    
    # 平均在院日数に関するインサイト
    alos = kpi_data.get("alos", 0)
    alos_mom_change = kpi_data.get("alos_mom_change", 0)
    
    if alos > 0:
        if alos < 14:
            insights["alos"].append("平均在院日数は14日未満で良好な水準です。")
        elif alos < 18:
            insights["alos"].append("平均在院日数は注意すべき範囲（14日～18日）にあります。")
        else:
            insights["alos"].append("平均在院日数が18日以上と長期化しています。改善が必要かもしれません。")
    
    if abs(alos_mom_change) > 5:
        trend_text = "減少" if alos_mom_change < 0 else "増加"
        insights["alos"].append(f"平均在院日数は前月比で{abs(alos_mom_change):.1f}%{trend_text}しています。")
        
        if alos_mom_change < -5:
            insights["alos"].append("平均在院日数の大幅な減少は、病床回転率の向上につながりますが、早期退院の適切性も確認しましょう。")
        elif alos_mom_change > 5:
            insights["alos"].append("平均在院日数の増加傾向には注意が必要です。退院支援の強化や長期入院患者の見直しを検討しましょう。")
    
    # 病床利用率に関するインサイト
    occupancy_rate = kpi_data.get("bed_occupancy_rate")
    if occupancy_rate is not None:
        if occupancy_rate > 90:
            insights["occupancy"].append(f"病床利用率が{occupancy_rate:.1f}%と非常に高くなっています。患者受入に影響が出る可能性があります。")
        elif occupancy_rate > 85:
            insights["occupancy"].append(f"病床利用率は{occupancy_rate:.1f}%と適正な水準です。効率的な病床運用ができています。")
        elif occupancy_rate > 75:
            insights["occupancy"].append(f"病床利用率は{occupancy_rate:.1f}%と許容範囲内ですが、収益面での最適化の余地があります。")
        else:
            insights["occupancy"].append(f"病床利用率が{occupancy_rate:.1f}%と低めです。空床が多い状況を改善するための対策を検討しましょう。")
    
    # 平日/休日パターンに関するインサイト
    weekday_avg = kpi_data.get("weekday_avg_census", 0)
    holiday_avg = kpi_data.get("holiday_avg_census", 0)
    
    if weekday_avg > 0 and holiday_avg > 0:
        weekday_holiday_diff = (weekday_avg - holiday_avg) / weekday_avg * 100 if weekday_avg > 0 else 0
        
        if abs(weekday_holiday_diff) > 15:
            if weekday_holiday_diff > 0:
                insights["weekday_pattern"].append(f"平日と休日で在院患者数に{abs(weekday_holiday_diff):.1f}%の差があります。平日の方が多くなっています。")
                insights["weekday_pattern"].append("休日の入院受入体制や退院調整を見直すことで、平準化できる可能性があります。")
            else:
                insights["weekday_pattern"].append(f"平日と休日で在院患者数に{abs(weekday_holiday_diff):.1f}%の差があります。休日の方が多くなっています。")
                insights["weekday_pattern"].append("平日の退院促進や入院受入体制を強化することを検討しましょう。")
    
    # 全般的なインサイト
    turnover_rate = kpi_data.get("turnover_rate", 0)
    if turnover_rate > 0:
        if turnover_rate < 0.7:
            insights["general"].append(f"病床回転率が{turnover_rate:.2f}回転と低めです。在院日数の適正化や入退院の効率化を検討しましょう。")
        elif turnover_rate > 1.0:
            insights["general"].append(f"病床回転率が{turnover_rate:.2f}回転と高く、効率的な病床運用ができています。")
    
    emergency_rate = kpi_data.get("emergency_admission_rate", 0)
    if emergency_rate > 30:
        insights["general"].append(f"緊急入院の割合が{emergency_rate:.1f}%と高くなっています。計画的な入院管理が難しい状況かもしれません。")
    
    # データの質に関するインサイト
    if len(insights["alos"]) == 0 and len(insights["occupancy"]) == 0 and len(insights["weekday_pattern"]) == 0 and len(insights["general"]) == 0:
        insights["general"].append("十分なデータが集まると、より詳細な分析インサイトが表示されます。")
    
    return insights