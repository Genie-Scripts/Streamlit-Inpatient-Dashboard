# forecast_analysis_tab.py のインポート部分を修正

import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
import time

# 既存のモジュールから必要な関数をインポート
# パスが通っていること、および関数が期待通りに動作することが前提です。
try:
    # forecast_models.py が存在しない場合は forecast.py から代替関数をインポート
    try:
        from forecast_models import (
            simple_moving_average_forecast,
            holt_winters_forecast,
            arima_forecast,
            prepare_daily_total_patients,
            generate_annual_forecast_summary,
        )
    except ImportError:
        # フォールバック: forecast.py から関数をインポート
        from forecast import (
            simple_moving_average_forecast,
            holt_winters_forecast,
            arima_forecast,
            prepare_daily_total_patients,
            generate_annual_forecast_summary,
        )
    
    # chart.py から関数をインポート
    from chart import create_forecast_comparison_chart
    
except ImportError as e:
    st.error(f"予測分析タブに必要なモジュールのインポートに失敗しました: {e}")
    st.error("以下のモジュールが存在するか確認してください:")
    st.error("- forecast.py または forecast_models.py")
    st.error("- chart.py")
    
    # モジュールがなければ、以降の処理でエラーになるため、ダミー関数等を定義
    prepare_daily_total_patients = None
    simple_moving_average_forecast = None
    holt_winters_forecast = None
    arima_forecast = None
    generate_annual_forecast_summary = None
    create_forecast_comparison_chart = None

def display_forecast_analysis_tab():
    """
    予測分析タブのUIとロジックを表示する関数。
    """
    st.header("🔮 予測分析")

    if 'data_processed' not in st.session_state or not st.session_state.data_processed:
        st.warning("まず「データ処理」タブでデータを読み込んでください。")
        return

    df = st.session_state.get('df')
    latest_data_date_str = st.session_state.get('latest_data_date_str')

    if df is None or df.empty:
        st.error("分析対象のデータフレームが読み込まれていません。")
        return
    if latest_data_date_str is None:
        st.error("データの最新日付が不明です。")
        return
        
    # 最新日付の変換
    try:
        latest_data_date = pd.to_datetime(latest_data_date_str, format="%Y年%m月%d日")
    except ValueError:
        st.error(f"最新データ日付の形式が無効です: {latest_data_date_str}")
        latest_data_date = pd.Timestamp.now().normalize()

    # 必要な関数が利用可能かチェック
    if not all([prepare_daily_total_patients, simple_moving_average_forecast, 
                holt_winters_forecast, arima_forecast, generate_annual_forecast_summary]):
        st.error("予測分析に必要な関数が利用できません。")
        st.error("forecast.py または forecast_models.py を確認してください。")
        return

    st.subheader("予測設定")
    col_pred_set1, col_pred_set2 = st.columns(2)

    with col_pred_set1:
        current_year = pd.Timestamp.now().year
        # データの最新日に基づいてデフォルトの予測対象年度を決定
        default_pred_year = latest_data_date.year
        if latest_data_date.month < 4: # 1-3月なら前年度の会計年度が進行中
            default_pred_year -= 1
        
        available_pred_years = list(range(default_pred_year - 1, default_pred_year + 3))
        try:
            default_pred_year_index = available_pred_years.index(default_pred_year)
        except ValueError:
            default_pred_year_index = 0

        predict_fiscal_year = st.selectbox(
            "予測対象年度",
            options=available_pred_years,
            index=default_pred_year_index,
            format_func=lambda year: f"{year}年度"
        )

    with col_pred_set2:
        model_options = ["単純移動平均", "Holt-Winters", "ARIMA"]
        selected_models = st.multiselect(
            "比較する予測モデルを選択",
            options=model_options,
            default=model_options[:2]  # デフォルトで最初の2つを選択
        )

    with st.expander("モデルパラメータ詳細設定（上級者向け）", expanded=False):
        sma_window = st.slider("単純移動平均: ウィンドウサイズ（日数）", 1, 90, 7, key="pred_sma_window")
        hw_seasonal_periods = st.slider("Holt-Winters: 季節周期（日数）", 1, 365, 7, key="pred_hw_seasonal_periods", help="週周期なら7、年周期なら365など。")
        arima_m = st.slider("ARIMA: 季節周期 (m)", 1, 52, 7, key="pred_arima_m", help="週周期の季節性(m=7)を考慮します。")

    if st.button("予測を実行", key="run_prediction_button_main", use_container_width=True):
        if not selected_models:
            st.warning("比較するモデルを1つ以上選択してください。")
        else:
            with st.spinner(f"{predict_fiscal_year}年度の患者数予測を実行中..."):
                forecast_start_time = time.time()
                
                # 予測用の日次全患者数データを準備
                try:
                    daily_total_patients = prepare_daily_total_patients(df)
                except Exception as e:
                    st.error(f"日次患者数データの準備に失敗しました: {e}")
                    return

                if daily_total_patients is None or daily_total_patients.empty:
                    st.error("予測用の日次患者数データを作成できませんでした。元データを確認してください。")
                    return
                    
                forecast_model_results_dict = {}
                forecast_annual_summary_list = []

                forecast_horizon_end_date = pd.Timestamp(f"{predict_fiscal_year + 1}-03-31")
                last_data_date_for_pred = daily_total_patients.index.max()
                
                horizon_days = 0
                if last_data_date_for_pred < forecast_horizon_end_date:
                    horizon_days = (forecast_horizon_end_date - last_data_date_for_pred).days
                
                if horizon_days <= 0:
                    st.warning(f"{predict_fiscal_year}年度末までの予測期間がありません。実績データが既に年度末を超えているか、対象年度を確認してください。")
                else:
                    # 各モデルで予測を実行
                    for model_name in selected_models:
                        pred_series = None
                        model_start_time = time.time()
                        
                        try:
                            if model_name == "単純移動平均":
                                pred_series = simple_moving_average_forecast(
                                    daily_total_patients, 
                                    window=sma_window, 
                                    forecast_horizon=horizon_days
                                )
                            elif model_name == "Holt-Winters":
                                pred_series = holt_winters_forecast(
                                    daily_total_patients, 
                                    seasonal_periods=hw_seasonal_periods, 
                                    forecast_horizon=horizon_days
                                )
                            elif model_name == "ARIMA":
                                pred_series = arima_forecast(
                                    daily_total_patients, 
                                    forecast_horizon=horizon_days, 
                                    m=arima_m
                                )
                            
                            if pred_series is not None and not pred_series.empty:
                                forecast_model_results_dict[model_name] = pred_series
                                
                                # 年度集計の生成
                                if generate_annual_forecast_summary:
                                    annual_sum = generate_annual_forecast_summary(
                                        daily_total_patients,
                                        pred_series,
                                        last_data_date_for_pred,
                                        predict_fiscal_year
                                    )
                                    forecast_annual_summary_list.append({
                                        "モデル名": model_name,
                                        "実績総患者数": annual_sum.get("実績総患者数"),
                                        "予測総患者数": annual_sum.get("予測総患者数"),
                                        f"{predict_fiscal_year}年度 総患者数（予測込）": annual_sum.get("年度総患者数（予測込）")
                                    })
                                    
                            model_end_time = time.time()
                            st.info(f"✅ {model_name}モデルの予測完了: {model_end_time - model_start_time:.2f}秒")
                            
                        except Exception as e_model:
                            st.warning(f"⚠️ {model_name}モデルの予測中にエラーが発生しました: {e_model}")
                            continue
                    
                    # セッションステートに結果を保存
                    st.session_state.forecast_model_results = forecast_model_results_dict
                    if forecast_annual_summary_list:
                        st.session_state.forecast_annual_summary_df = pd.DataFrame(forecast_annual_summary_list).set_index("モデル名")
                    else:
                        st.session_state.forecast_annual_summary_df = pd.DataFrame()

                    forecast_end_time = time.time()
                    st.success(f"🎉 {predict_fiscal_year}年度の患者数予測が完了しました。処理時間: {forecast_end_time - forecast_start_time:.1f}秒")

    # --- 予測結果表示 ---
    if 'forecast_model_results' in st.session_state and st.session_state.forecast_model_results:
        st.subheader(f"📊 {predict_fiscal_year}年度 全日入院患者数予測結果")

        # 予測比較グラフの表示
        if create_forecast_comparison_chart:
            st.markdown("##### 📈 予測比較グラフ")
            
            # グラフ用のデータを再度準備
            try:
                daily_total_patients_for_chart = prepare_daily_total_patients(df)
            except Exception as e:
                st.error(f"グラフ用データの準備に失敗しました: {e}")
                daily_total_patients_for_chart = pd.Series()
            
            if not daily_total_patients_for_chart.empty:
                # 表示期間の調整
                display_past_days_chart = 180 
                forecast_end_date_chart = pd.Timestamp(f"{predict_fiscal_year + 1}-03-31")
                display_future_days_chart = (forecast_end_date_chart - daily_total_patients_for_chart.index.max()).days + 1
                display_future_days_chart = max(0, display_future_days_chart)

                try:
                    forecast_comparison_fig = create_forecast_comparison_chart(
                        daily_total_patients_for_chart,
                        st.session_state.forecast_model_results,
                        title=f"{predict_fiscal_year}年度 全日入院患者数予測比較",
                        display_days_past=display_past_days_chart,
                        display_days_future=display_future_days_chart 
                    )
                    
                    if forecast_comparison_fig:
                        st.plotly_chart(forecast_comparison_fig, use_container_width=True)
                    else:
                        st.warning("予測比較グラフの生成に失敗しました。")
                        
                except Exception as e:
                    st.error(f"予測比較グラフの作成中にエラー: {e}")
            else:
                st.warning("グラフ用データが準備できませんでした。")
        else:
            st.warning("グラフ生成関数 (create_forecast_comparison_chart) が利用できません。")

        # 年度総患者数予測テーブル
        if ('forecast_annual_summary_df' in st.session_state and 
            st.session_state.forecast_annual_summary_df is not None and 
            not st.session_state.forecast_annual_summary_df.empty):
            st.markdown("##### 📋 年度総患者数予測（各モデル別）")
            st.dataframe(
                st.session_state.forecast_annual_summary_df.style.format("{:,.0f}"), 
                use_container_width=True
            )
        else:
            st.info("年度総患者数の集計結果はありません。")

        # 詳細データの表示
        with st.expander("🔍 各モデルの日次予測データ詳細を見る"):
            for model_name, pred_series_data in st.session_state.forecast_model_results.items():
                if pred_series_data is not None and not pred_series_data.empty:
                    st.markdown(f"###### {model_name}モデルによる日次予測")
                    # 最初の100日分を表示
                    display_data = pred_series_data.head(100).round(1).rename("予測患者数")
                    st.dataframe(display_data, use_container_width=True, height=300)
                else:
                    st.markdown(f"###### {model_name}モデル")
                    st.text("予測データがありません。")
                    
    elif st.session_state.get('data_processed', False):
        st.info("上記で予測対象年度とモデルを選択し、「予測を実行」ボタンを押してください。")

    # 予測に関する注意事項
    with st.expander("ℹ️ 予測に関する注意事項", expanded=False):
        st.markdown("""
        **予測モデルについて:**
        - **単純移動平均**: 過去N日間の平均値を使用した単純な予測手法
        - **Holt-Winters**: 季節性を考慮した指数平滑化手法
        - **ARIMA**: 自己回帰統合移動平均モデル
        
        **予測の限界:**
        - 予測は過去のデータパターンに基づいています
        - 外部要因（医療政策変更、感染症流行等）は考慮されていません
        - 予測精度は過去データの品質と期間に依存します
        
        **活用方法:**
        - 複数モデルの結果を比較して判断してください
        - 予測値は参考値として、実際の計画では余裕を持った設定を推奨します
        """)